﻿namespace Library_Management_Domain
{
    public class Class1
    {

    }
}
