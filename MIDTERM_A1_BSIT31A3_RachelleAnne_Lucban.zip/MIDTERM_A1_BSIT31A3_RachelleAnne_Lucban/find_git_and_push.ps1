Write-Host "=== SEARCHING FOR GIT AND PUSHING MIDTERM A2 ===" -ForegroundColor Cyan
Write-Host ""

# Extended search for Git
$gitLocations = @(
    "C:\Program Files\Git\bin\git.exe",
    "C:\Program Files (x86)\Git\bin\git.exe",
    "C:\Program Files\Git\cmd\git.exe",
    "C:\Program Files (x86)\Git\cmd\git.exe",
    "$env:USERPROFILE\AppData\Local\Programs\Git\bin\git.exe",
    "$env:LOCALAPPDATA\Programs\Git\bin\git.exe",
    "$env:PROGRAMFILES\Git\bin\git.exe"
)

$gitFound = $null

Write-Host "Searching for Git installation..." -ForegroundColor Yellow

foreach ($location in $gitLocations) {
    if (Test-Path $location -ErrorAction SilentlyContinue) {
        try {
            $version = & $location --version 2>$null
            if ($version) {
                $gitFound = $location
                Write-Host "✅ Found Git at: $location" -ForegroundColor Green
                Write-Host "   Version: $version" -ForegroundColor Gray
                break
            }
        } catch {
            continue
        }
    }
}

if (-not $gitFound) {
    Write-Host "❌ Git not found in standard locations" -ForegroundColor Red
    Write-Host ""
    Write-Host "SOLUTION OPTIONS:" -ForegroundColor Yellow
    Write-Host "1. Download GitHub Desktop: https://desktop.github.com/" -ForegroundColor White
    Write-Host "2. Install Git: https://git-scm.com/download/win" -ForegroundColor White
    Write-Host "3. Use VS Code with Git extension" -ForegroundColor White
    Write-Host ""
    Write-Host "Your files are ready - just need a Git client to push them!" -ForegroundColor Cyan
    exit 1
}

Write-Host ""
Write-Host "Using Git: $gitFound" -ForegroundColor Green
Write-Host ""

# Try to push
try {
    Write-Host "Step 1: Checking repository status..." -ForegroundColor Yellow
    & $gitFound status --short
    Write-Host ""
    
    Write-Host "Step 2: Adding all changes..." -ForegroundColor Yellow
    & $gitFound add .
    
    Write-Host "Step 3: Committing changes..." -ForegroundColor Yellow
    & $gitFound commit -m "MIDTERM A2: Complete implementation of Author CRUD, Book pullout, and Archiving features

All requirements implemented:
✅ Author CRUD operations
✅ Author details with book listings  
✅ Book copy pullout with reasons
✅ Archiving system with restore
✅ Enhanced navigation and UI"
    
    Write-Host "Step 4: Creating branch..." -ForegroundColor Yellow
    & $gitFound checkout -b "MIDTERM_A2_BSIT31A3_RachelleAnne_Lucban"
    
    Write-Host "Step 5: Pushing to GitHub..." -ForegroundColor Yellow
    & $gitFound push -u origin "MIDTERM_A2_BSIT31A3_RachelleAnne_Lucban"
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "🎉 SUCCESS! Branch pushed to GitHub!" -ForegroundColor Green
        Write-Host ""
        Write-Host "View your branch at:" -ForegroundColor Cyan
        Write-Host "https://github.com/rclucban/MIDTERM_A1_BSIT31A3_RachelleAnne_Lucban/tree/MIDTERM_A2_BSIT31A3_RachelleAnne_Lucban" -ForegroundColor Blue
    } else {
        Write-Host ""
        Write-Host "❌ Push failed - possible authentication issue" -ForegroundColor Red
        Write-Host "Try using GitHub Desktop for easier authentication" -ForegroundColor Yellow
    }
    
} catch {
    Write-Host ""
    Write-Host "❌ Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Try using GitHub Desktop or VS Code instead" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Press Enter to continue..." -ForegroundColor Gray
Read-Host
